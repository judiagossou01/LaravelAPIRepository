<?php

return [
    'status' => true,
    'message' => 'Welcome to Digitpay API',
    'data' => [
        'service' => 'Digitpay API',
        'version' => '1.0',
        'language' => app()->getLocale(),
        'apikey' => 'e8e4b03d652fbfffbb22acd109818810',
        'support' => 'contact@ujima.sarl'
    ]
];
